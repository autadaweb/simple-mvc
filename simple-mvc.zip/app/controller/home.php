<?php


class Home extends Controller{

    public function index()
    {
        $data = 'Hello World!';
        $this->view('home/index',$data);
    }
}