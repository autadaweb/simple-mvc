<?php

//Base url
define('BASEURL', 'http://localhost/my-mvc/public/');



//database alamat
define('APP_NAME','Autada MVC');

//data encripsi
define('KEY','b867543tybcc678ytrhhhh787jQRedkiyuytrWBpedsJLKfgAf');
define('IV','abvfgrtyjhd567aa');


//konfigurasi email
define('EMAIL','youremail@gmail.com');
define('HOST_EMAIL','mail.host.com');
define('PASS_EMAIL','password');
define('PORT_EMAIL','465');



//database
define("HOSTNAME", 'localhost');
define("USER", 'root');
define("PASS", '');
define("DB_DATA", '');
define("DB_ADMIN", '');



