<?php

class Database{

    
    private $host = HOSTNAME;
    private $user = USER;
    private $pass = PASS;
    private $db_name = DB_DATA;
    private $db_admin = DB_ADMIN;


    public function __construct()
    {
        $conn = mysqli_connect($this->host,$this->user,$this->pass,$this->db_name);

        if(!$conn){

            echo "GALAT PADA DATABASE";
        }
    }


        public function conn()
        {
            $conn = mysqli_connect($this->host,$this->user,$this->pass,$this->db_name);

            return $conn;

        }


        public function conn_admin()
        {
            $conn = mysqli_connect($this->host,$this->user,$this->pass,$this->db_admin);

            return $conn;

        }


    public function bind($data){

        $data = mysqli_real_escape_string($this->conn(), $data);
        return $data;

    }


    

}
