<?php
class Encrip{

    
   public static function encr($code){
        $method = "AES-128-CTR";
        $key = KEY;
        $iv = IV;
        $encript = openssl_encrypt($code,$method,$key,0,$iv);
        
        return $encript;
        }
        
        
      public static  function decr($code){
            $method = "AES-128-CTR";
            $key = KEY;
            $iv = IV;
            $encript = openssl_decrypt($code,$method,$key,0,$iv);

        
            return $encript;
        }



}