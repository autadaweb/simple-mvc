<?php

class Redirect{


    public static function url($url){


        header("location:".$url);


    }


    public static function Baseurl($dir){

        
        header("location:".BASEURL.$dir);
        exit;


    }

}